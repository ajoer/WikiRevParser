from .wikirevparser import *
